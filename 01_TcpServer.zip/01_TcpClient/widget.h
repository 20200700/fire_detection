#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include "GPIO_PWM_API.h"
#include "I2C_API.h"
#include "thread.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private:
    Thread *thread;

public:
    Ui::Widget *ui;
    I2C_SHT20 *SHT20;
    I2C_PCA9685 *RGB_LED[3];


    void initialize();
    void chkChanged(bool value);
    QTcpSocket *tcpSocket;

private slots:
    void connectButton();
    void readMessage(); // 서버로부터 메세지를 받을 때 호출 됨
    void disconnected();
};

#endif // WIDGET_H

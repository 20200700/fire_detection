#ifndef THREAD_H
#define THREAD_H

#include <QThread>
#include <QtDebug>

#define SHT20_I2C_ADDR 0x40
#define SHT20_I2C_ADDR 0x40
#define SHT20_I2C_CMD_MEASURE_TEMP 0xF3

class Thread : public QThread
{
    Q_OBJECT

public:
    explicit Thread(QObject *parent = 0);

private:
    int mFd;
    float temp = 0.0;
    int value;
    int aData[2];
    void run();
};

#endif // THREAD_H

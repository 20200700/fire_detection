#include "widget.h"
#include <QApplication>
#include <QObject>
#include <wiringPi.h>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.setWindowTitle("TCP 클라이언트");
    w.show();


    //QTcpSocket *ServerConnection;


    return a.exec();
}



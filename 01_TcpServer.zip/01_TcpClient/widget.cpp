#include "widget.h"
#include "ui_widget.h"
#include <QHostAddress>
#include <QDebug>
#include <iostream>
#include <pthread.h>
using namespace std;

Widget::Widget(QWidget *parent) :
    QWidget(parent), ui(new Ui::Widget)
{
    int i;
    ui->setupUi(this);

    connect(ui->connectButton, SIGNAL(clicked()),this,SLOT(connectButton()));

    initialize();

    for(i = 0; i<3;i++){
        RGB_LED[i] = new I2C_PCA9685(RGB_I2C_ADDR, i);
    }
}

//서버로부터 메시지를 받으면 readMessage() 함수를 호출,
//서버와 연결이 종료되면 disconnect() slot함수 호출
void Widget::initialize()
{
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, SIGNAL(readyRead()),
            this,      SLOT(readMessage()));
    connect(tcpSocket, SIGNAL(disconnected()),
            this,      SLOT(disconnected()));
}

//접속 버튼 클릭 시 호출
void Widget::connectButton()
{
    QString serverip   = ui->serverIP->text().trimmed();

    QHostAddress serverAddress(serverip);
    tcpSocket->connectToHost(serverAddress, 25000);
    char message2[100];

    tcpSocket->read(message2,100);


   //cout << message2 << endl;
}


//서버로부터 메시지를 받는 시그널이 발생하면 호출되는 함수
void Widget::readMessage()
{
    if(tcpSocket->bytesAvailable() >= 0)
    {
        QByteArray readData = tcpSocket->readAll();
        ui->textEdit->append(readData);
    }
}

//서버로부터 접속이 종료된 시그널이 발생하면 호출되는 함수
void Widget::disconnected()
{
    qDebug() << Q_FUNC_INFO << "서버 접속 종료.";
}

Widget::~Widget()
{
    delete ui;
}



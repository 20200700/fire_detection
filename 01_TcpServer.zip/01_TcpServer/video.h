#ifndef VIDEO_H
#define VIDEO_H

class video
{
public:
    video();
    ~video();
    void fire_detection();

};

#endif // VIDEO_H

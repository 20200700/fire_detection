#include <vector>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core_c.h>
#include <video.h>

#define DETECTION_VAlUE 400 //cctv의 거리에 따라서 조절 필수

int FIRE_DETECTION =0;

using namespace cv;
using namespace std;

video::video()
{
    VideoCapture cap;
    cap.open(0);

    if(!cap.isOpened()){
        cout<<"Can not open camera!"<<endl;
        return;
    }

    Mat originalFrame;
    Mat resultFrame;

    vector<Mat> channels;
    vector<Mat> fireImage;

    Ptr<BackgroundSubtractor> pMOG2;
   pMOG2 = createBackgroundSubtractorMOG2();

    int pixFiredetection;
    int pixFiredetectionSum=0;
    int count = 0;
    int pixFiredetectionAvg;

    while(1){
        pixFiredetection=0;

        cap >> originalFrame;

        medianBlur(originalFrame, resultFrame,3);

        split(resultFrame, channels);

        for(int j=0; j<channels[2].rows; j++){
            for(int i=0;i<channels[2].cols;i++){
                if(channels[2].at<uchar>(j,i)<150){
                    channels[2].at<uchar>(j,i) = 0;
                }
                if(channels[2].at<uchar>(j,i)>=150){
                    pixFiredetection++;
                }
            }
        }

        count ++;

        if(count>100){
            pixFiredetectionSum += pixFiredetection;
            pixFiredetectionAvg = pixFiredetectionSum/(count-100);
//                /*=======test======*/
//                cout<<"현재 프레임 픽셀 수의 합 : " << pixFiredetectionSum<<endl;
//                cout<<"현재 프레임 수 : "<<count-100 << endl;
//                cout<<"평균 픽셀 수 : "<<pixFiredetectionAvg<<endl;
//                cout<<"현재 픽셀 수 : "<< pixFiredetection<<endl;
        }


        if(count==200){
                cout<<"the detection is ready!!"<<endl;

        }
        if((pixFiredetectionAvg + DETECTION_VAlUE < pixFiredetection)&&count>=200){
            cout<<"fire is detected!! ("<<pixFiredetection<<")"<<endl;
            FIRE_DETECTION =1;
        }

        Mat temp =  channels[2];
        pMOG2->apply(temp,temp);
        channels.clear();


        imshow("fire detection in video",temp);
        imshow("original video",originalFrame);

        if(waitKey(30) == 27){
            FIRE_DETECTION=0;
            break;
        }
    }
}

video::~video()
{

}


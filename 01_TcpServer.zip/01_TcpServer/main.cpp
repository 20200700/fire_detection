#include "widget.h"
#include "thread.h"
#include "pca9685.h"
#include "GPIO_PWM_API.h"
#include "video.h"

#include <QApplication>
#include <pthread.h>
#include <iostream>

using namespace std;

void* Temp(void* arg);
void* video_thread(void* arg);
void* led_thread(void* arg);
void* siren_thread(void* arg);

int danger = 0;
I2C_PCA9685 ledRed(0x5E, 0);
TONE_PIEZO siren(12);

pthread_t led_t_id;
pthread_t siren_t_id;

Widget* pw;
video* pvideo;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    pw = &w;
    w.setWindowTitle("TCP 서버");
    w.show();

    pthread_t temp_t_id;
    pthread_create(&temp_t_id, NULL, Temp, NULL);

    video* hi;
    pvideo = hi;

    pthread_t video_t_id;
    pthread_create(&video_t_id, NULL, video_thread, NULL);

//    hi = new video();
    return a.exec();
}

void* Temp(void* arg)
{
    while(1)
    {
        pw->temp = pw->sht20->measureTemp();

        if(pw->temp > 30)
        {
            danger = 1;
//            cout << "위험" << endl;
            pthread_create(&led_t_id, NULL, led_thread, NULL);
            pthread_create(&siren_t_id, NULL, siren_thread, NULL);
        }
        else
        {
            danger = 0;
            cout << pw->temp << endl;
        }

        delay(1000);
    }
}

void* video_thread(void* arg)
{
    pvideo = new video();

    return NULL;
}

void* led_thread(void* arg)
{
    while(1)
    {
        if (danger == 0)
            pthread_exit(NULL);
        ledRed.setPwm((bool)HIGH);
        delay(100);
        ledRed.setPwm((bool)LOW);
        delay(100);
    }

    return NULL;
}

void* siren_thread(void* arg){
    while(1)
    {
        for(int i = 150; i <= 1800; i += 2)
        {
            if (danger == 0)
                pthread_exit(NULL);
            siren.setScaleOnTime(i, 10);
        }
    }
}

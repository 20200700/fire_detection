//#include "thread.h"
//#include "I2C_API.h"
//#include "widget.h"
//#include <wiringPi.h>
//#include <wiringPiI2C.h>
//#include <iostream>
//using namespace std;

//float temp = 0.0;
//I2C_SHT20 sht20(SHT20_I2C_ADDR);

//Thread::Thread(QObject *parent) :
//    QThread(parent)
//{

//}
//void Thread::run()
//{

//    while(1)
//      {
//        temp = sht20.measureTemp();

//        //cout << temp << endl;

//        if(temp > 31)
//        {
//            cout << "위험" << endl;
//        }
//        else
//        {
//            cout << temp << endl;
//        }

//        delay(1000);
//      }


//    //return temp;

//}

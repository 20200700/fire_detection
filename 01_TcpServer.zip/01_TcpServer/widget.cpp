#include "widget.h"
#include "ui_widget.h"
//#include "thread.h"
#include <wiringPi.h>
#include <softPwm.h>
#include <QtWidgets>
#include <QDebug>
#include <QTcpSocket>
#include <pthread.h>
#include <iostream>
#include <stdlib.h>
using namespace std;

Widget::Widget(QWidget *parent) : QWidget(parent), ui(new Ui::Widget)
{
    ui->setupUi(this);

//    thread = new Thread(this);
//    thread->start();
    sht20 = new I2C_SHT20(SHT20_I2C_ADDR);

//    led = new I2C_PCA9685(RGB_I2C_ADDR, 0);

    initialize();
}

void Widget::initialize()
{
    QHostAddress hostAddress;
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    // localhost(127.0.0.1) 가 아닌 것을 사용
    for (int i = 0; i < ipAddressesList.size(); ++i) {
        if (ipAddressesList.at(i) != QHostAddress::LocalHost &&
            ipAddressesList.at(i).toIPv4Address()) {
            hostAddress = ipAddressesList.at(i);
            break;
        }
    }

    if (hostAddress.toString().isEmpty())
        hostAddress = QHostAddress(QHostAddress::LocalHost);

    tcpServer = new QTcpServer(this);
    if (!tcpServer->listen(hostAddress, 25000)) {
        QMessageBox::critical(this, tr("TCP Server"),
                              tr("서버를 시작할 수 없습니다. 에러메세지 : %1.")
                              .arg(tcpServer->errorString()));
        close();
        return;
    }

    ui->labelStatus->setText(tr("서버 동작 중 \n\n"
                                "IP : %1\n"
                                "PORT : %2\n")
                         .arg(hostAddress.toString())
                             .arg(tcpServer->serverPort()));

    connect(tcpServer, SIGNAL(newConnection()), this, SLOT(newConnection()));

    ui->connMsgEdit->clear();
}

void Widget::newConnection()
{
    QTcpSocket *clientConnection = tcpServer->nextPendingConnection();
    connect(clientConnection, SIGNAL(disconnected()),
            clientConnection, SLOT(deleteLater()));

    QString currTime = QTime::currentTime().toString("hh시 mm분 ss초");
    QString text = QString("클라이언트 접속 (%1)").arg(currTime);

    ui->connMsgEdit->append(text);
    //QByteArray message = QByteArray("Hello Client ~ ");
    char message[100]; 
    sprintf(message, "%d", temp);
    clientConnection->write(message);


//    char message2[100]="test";
//    clientConnection->read(message2,100);
//    cout << message2 <<endl;
    clientConnection->disconnectFromHost();


}

Widget::~Widget()
{
    delete ui;
}

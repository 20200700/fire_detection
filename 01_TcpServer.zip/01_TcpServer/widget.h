#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QtNetwork>
#include "thread.h"
#include "I2C_API.h"
#include "GPIO_PWM_API.h"
#include "pca9685.h"

class QTcpServer;
class QNetworkSession;

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

public:
    Ui::Widget *ui;
    void initialize();
    QTcpServer *tcpServer;
    //Thread *thread;
    int temp = 0;
    I2C_SHT20* sht20;
    TONE_PIEZO* siren;
    I2C_PCA9685* led;

private slots:
    void newConnection();
};

#endif // WIDGET_H

#ifndef GPIO_PWM_API_H
#define GPIO_PWM_API_H

#define PIEZO_PIN 12
// TONE_PIEZO
class TONE_PIEZO {
    private:
        int mPinNum;
        int mScale;
//        int mTime;
    public:
        TONE_PIEZO(int pin);
        ~TONE_PIEZO();
        void setScaleOn(int scale);
        void setScaleOnTime(int scale, int time);
        void setScaleOFF(void);
        void setMelody(int scale[], int time[], int cnt);
        void setMelodyStruct(struct scaleTime song);
};
#endif // GPIO_PWM_API_H

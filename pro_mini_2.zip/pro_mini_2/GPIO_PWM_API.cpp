#include <iostream>
using namespace std;

//#include <QDebug>
#include "GPIO_PWM_API.h"
#include <wiringPi.h>
#include <softPwm.h>
#include <softTone.h>
#include "piezo.h"

// ====================  TONE_PIEZO ========================
// 생성자
TONE_PIEZO::TONE_PIEZO(int pin)
{
    mPinNum = pin;

    wiringPiSetupGpio();

    softToneCreate(pin);
}

// 소멸자
TONE_PIEZO::~TONE_PIEZO()
{
    softToneStop(mPinNum);
}

// 멤버 함수
void TONE_PIEZO::setScaleOn(int scale)
{
    mScale = scale;
    softToneWrite(mPinNum, mScale);
}

void TONE_PIEZO::setScaleOnTime(int scale, int time)
{
    mScale = scale;
    softToneWrite(mPinNum, mScale);
    delay(time);
    setScaleOFF();
}

void TONE_PIEZO::setScaleOFF(void)
{
    softToneWrite(mPinNum, S_mute);
}

void TONE_PIEZO::setMelody(int *scale, int *time, int cnt)
{
    for (int i = 0; i < cnt; i++)
    {
        setScaleOnTime(scale[i], time[i]);
    }
}

void TONE_PIEZO::setMelodyStruct(struct scaleTime song)
{
    for (int i = 0; i < song.cnt; i++)
    {
        setScaleOnTime(song.scale[i], song.time[i]);
    }
}
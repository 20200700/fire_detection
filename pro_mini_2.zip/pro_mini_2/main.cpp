#include "pca9685.h"

#include <wiringPi.h>
#include <wiringPiI2C.h>

#include <stdio.h>
#include <stdlib.h>

#include "I2C_API.h"

#include "GPIO_PWM_API.h"

#include <thread>
using std::thread;
using namespace std;
#include <unistd.h>
#include <iostream>

void signal_led(){
    I2C_PCA9685 ledRed(PCA9685_I2C_ADDR, 0);

    while(1){
      cout <<"쓰레드 1 작동중\n";
      ledRed.setPwm((bool)HIGH);
      delay(100);
      ledRed.setPwm((bool)LOW);
      delay(100);
    }
}

void signal_siren(){
  TONE_PIEZO siren(PIEZO_PIN);

  while(1){
    cout <<"쓰레드 2 작동중\n";
    for(int i = 150; i <= 1800; i += 2){
    siren.setScaleOnTime(i, 10);
    }
    for(int i = 1800; i <= 150; i += 2){
      siren.setScaleOnTime(i, 10);
    }
  }
}


int main(void)
{
  thread t1(signal_led);
  thread t2(signal_siren);

  t2.join();
}

